import telebot
from telebot import types
from telebot.types import WebAppInfo
import json

bot = telebot.TeleBot('5874798151:AAG1Hr-YhsAfAdCQrtW2Af3m1nCwXNOhX34')

@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup()
    markupm = types.KeyboardButton('Открыть магазин', web_app=WebAppInfo(url='https://acseer.github.io/TrainersShop/'))
    markupk = types.KeyboardButton('Открыть канал с кроссовками', web_app=WebAppInfo(url='https://t.me/trainersshop'))
    markupi = types.KeyboardButton('/info')
    markuph = types.KeyboardButton('/help')
    markup.add(markupm, markupk)
    markup.add(markupi, markuph)
    bot.send_message(message.chat.id, f'Здравствуйте, {message.from_user.first_name}!', reply_markup=markup)




@bot.message_handler(commands=['info'])
def info(message):
     bot.send_message(message.chat.id, '<b>Информация о Боте</b>\
                                        В этом боте вы можете купить, получить ссылку на канал с кроссовками, поддержать разработчика бота, получить информацию как произвести оплату и как работает магазин.', parse_mode='html')


@bot.message_handler(commands=['help'])
def help(message):
    bot.send_message(message.chat.id, '<b>Помощь в покупке</b>\
                                      Нажмите в главном меню на кнопку "Открыть магазин" там нажмите "Купить", введите нужные данные, оплатите, ждите поссылку', parse_mode='html')


@bot.message_handler()
def info(message):
    bot.reply_to(message, 'Извините, но я не знаю такой команды.')



@bot.message_handler(content_types="web_app_data") #получаем отправленные данные
def answer(webAppMes):
    res = json.loads(webAppMes.web_app_data.data)
    bot.send_message(webAppMes.chat.id, f"Name: {res['name']}. Email: {res['email']}. Phone: {res['phone']}. Cross: {res['cross']}")




bot.polling(none_stop=True)